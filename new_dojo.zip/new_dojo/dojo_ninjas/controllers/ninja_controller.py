from dojo_ninjas import app
from flask import render_template,redirect,request
from dojo_ninjas.models import ninjas_model, dojo_model
from dojo_ninjas.models.dojo_model import Dojo
from dojo_ninjas.models.ninjas_model import Ninja



@app.route("/dojo/new_ninja")
def new_ninja():
    dojo = Dojo.get_all()
    return render_template("new_ninjas.html", dojo = dojo)




@app.route("/dojo/new_ninja_created", methods = ["POST"])
def created_ninja():
    Ninja.save(request.form)
    return redirect("/dojo")