
from dojo_ninjas import app
from dojo_ninjas.controllers import dojo_controller,ninja_controller

if __name__ == "__main__":
    app.run(debug=True)